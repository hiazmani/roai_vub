
(deffacts startup  ; To assert 3 facts every time the system is reset
  (animal dog)
  (animal duck)
  (animal cat)) ; even if they are retracted they will reappear after a (reset)

  
(defrule animal 	; prints "animal found" 3 times
 ; (declare (salience 5))
  (animal ?)
  =>
  (printout t "animal found" crlf))

  
(defrule list-animals  	; prints the name of each animal found
(animal ?name)
=>
(printout t ?name " found" crlf))
  

