(deffacts startup  ; To assert 3 facts every time the system is reset
  (animal dog)
  (animal duck)
  (animal cat) 
  (warm-blooded dog) 
  (warm-blooded cat) 
  (warm-blooded duck) 
  (lays-eggs duck) 
  (lays-eggs turtle) 
  (child-of dog puppy) 
  (child-of cat kitten) 
  (child-of turtle hatchling))

; Define a function to print a message
(deffunction print-message (?text ?name)
   (printout t ?name " " ?text crlf))

(defrule list-animals  	; prints the name of each animal found
	(animal ?name)
	=>
	(print-message "found" ?name))

(defrule mammal
  (animal ?name)
  (warm-blooded ?name)
  (not (lays-eggs ?name))
  =>
  (assert (mammal ?name)))
;  (print-message "is a mammal" ?name))

(defrule remove-mammals   ; remove the fact (animal ?) if it is a mammal
  ?fact <- (mammal ?animal)
  ?fact2 <- (animal ?animal)
  =>
  (print-message "is being retracted" ?animal)
  (retract ?fact2)
  (retract ?fact))


