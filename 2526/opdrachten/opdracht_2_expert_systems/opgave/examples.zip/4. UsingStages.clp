; Start the process by asserting the initial stage
(deffacts initial-state
   (stage asking-symptoms))  ; We start by asking symptoms

; Rule to ask about fever
(defrule ask-symptom-fever
   (stage asking-symptoms)
   (not (asked fever))  
   =>
   (printout t "Does the patient have fever? (yes/no): ")
   (bind ?response (read))
   (if (eq ?response yes) then (assert (fever)))
   (assert (asked fever))
)

; Rule to ask about cough
(defrule ask-symptom-cough
   (stage asking-symptoms)
   (not (asked cough))  
   =>
   (printout t "Does the patient have cough? (yes/no): ")
   (bind ?response (read))
   (if (eq ?response yes) then (assert (cough)))
   (assert (asked cough))
)

; Rule to ask about body ache
(defrule ask-symptom-body-ache
   (stage asking-symptoms)
   (not (asked body-ache))  
   =>
   (printout t "Does the patient have body ache? (yes/no): ")
   (bind ?response (read))
   (if (eq ?response yes) then (assert (body-ache)))
   (assert (asked body-ache))
)

; Rule to ask about sneezing
(defrule ask-symptom-sneezing
   (stage asking-symptoms)
   (not (asked sneezing))  
   =>
   (printout t "Does the patient have sneezing? (yes/no): ")
   (bind ?response (read))
   (if (eq ?response yes) then (assert (sneezing)))
   (assert (asked sneezing))
)

; Rule to ask about mild fever
(defrule ask-symptom-mild-fever
   (stage asking-symptoms)
   (not (asked mild-fever))  
   =>
   (printout t "Does the patient have mild fever? (yes/no): ")
   (bind ?response (read))
   (if (eq ?response yes) then (assert (mild-fever)))
   (assert (asked mild-fever))
)

; Only move to the "diagnosis" stage when all symptoms are asked
(defrule move-to-diagnosis
   (stage asking-symptoms)   ; Still in symptom-asking stage
   (asked fever)
   (asked cough)
   (asked body-ache)
   (asked sneezing)
   (asked mild-fever)
   =>

   (assert (stage diagnosis))          ; Move to diagnosis stage
)

; Rule to diagnose flu
(defrule flu-diagnosis
   (stage diagnosis)   ; Only diagnose when in the correct stage
   (fever)    
   (cough)    
   (body-ache)  
   =>
   (assert (diagnosis flu))
   (printout t "Diagnosis: The patient likely has the flu." crlf))

; Rule to diagnose cold
(defrule cold-diagnosis
   (stage diagnosis)   ; Only diagnose when in the correct stage
   (sneezing)    
   (mild-fever)    
   =>
   (assert (diagnosis cold))
   (printout t "Diagnosis: The patient likely has a cold." crlf))

; If no diagnosis was found, print "no illness"
(defrule no-diagnosis
   (stage diagnosis)   ; Only check for diagnosis after all symptoms are asked
   (not (diagnosis ?)) ; No diagnosis exists
   =>
   (printout t "The patient does not have any diagnosed illness." crlf)
)
