(deffacts startup  ; To assert facts every time the system is reset
  (animal dog)
  (animal duck)
  (animal cat) 
  (warm-blooded dog) 
  (warm-blooded cat) 
  (warm-blooded duck) 
  (lays-eggs duck) 
  (lays-eggs turtle) 
  (child-of dog puppy) 
  (child-of cat kitten) 
  (child-of turtle hatchling))
  

(defrule list-animals  	; prints the name of each animal found
	(animal ?name)
	=>
	(printout t ?name " found" crlf))
  

(defrule mammal
  (animal ?name)
  (warm-blooded ?name)
  (not (lays-eggs ?name))
  =>
  (assert (mammal ?name))
  (printout t ?name " is a mammal" crlf))

(defrule remove-mammals   ; remove the fact (animal ?) if it is a mammal
  ?fact <- (mammal ?animal)
  ?fact2 <- (animal ?animal)
  =>
  
  (printout t "retracting " ?fact2 crlf)
  (retract ?fact2))

